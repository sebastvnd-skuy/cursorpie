//! # Extending CursorPie: recipes
//!
//! Each recipe lists the files to touch, in the order that keeps the project compiling. File
//! paths are relative to `src/`. Read [`architecture`](super::architecture) first.
//!
//! * [Add an action kind](#add-an-action-kind)
//! * [Add a setting](#add-a-setting)
//! * [Add a ready-made slice](#add-a-ready-made-slice)
//! * [Add a slice kind](#add-a-slice-kind)
//! * [Add a Settings tab](#add-a-settings-tab)
//! * [Add icons to the picker](#add-icons-to-the-picker)
//! * [Keep the Settings look consistent](#keep-the-settings-look-consistent)
//! * [Add a message to the UI thread](#add-a-message-to-the-ui-thread)
//! * [Add a menu bar item](#add-a-menu-bar-item)
//! * [Cache something in the UI](#cache-something-in-the-ui)
//! * [Keep the profile rules](#keep-the-profile-rules)
//! * [Make a change undoable](#make-a-change-undoable)
//! * [Change gesture behavior](#change-gesture-behavior)
//! * [Rebrand a fork](#rebrand-a-fork)
//!
//! ## Add an action kind
//!
//! Example: "Open a file in a given app".
//!
//! 1. `config/model.rs`: add a variant to [`Action`](crate::config::Action). Variants are
//!    serialized by name, so choose it carefully: it is part of the file format.
//! 2. `actions.rs`: handle it in `execute`. If it sends keystrokes, also return `true` for it in
//!    `sends_keys` so the target app is brought to the front first.
//! 3. `config/tree.rs`: if it can run arbitrary code, make
//!    [`has_commands`](crate::config::has_commands) return `true` for it (that drives the
//!    "this config runs shell commands" warning after an import).
//! 4. `ui/settings/action_editor.rs`: add it to `KINDS`, `action_index`, `make_action` and the
//!    input row. The `Sequence` kind shows how to add a kind the editor cannot edit yet.
//! 5. Add a unit test next to the code (see `actions::tests`).
//!
//! ## Add a setting
//!
//! 1. `config/model.rs`: add a field to [`Config`](crate::config::Config) with a doc comment.
//!    The struct is `#[serde(default)]`, so older files keep loading.
//! 2. `config/defaults.rs`: set its value in `impl Default for Config`.
//! 3. `config/sanitize.rs`: clamp it if it has a range, and add a case to `config/mod.rs` tests.
//! 4. `ui/settings/tabs/behavior.rs`: add the widget (it edits `self.edit`, the *copy* of the
//!    config, which *Save* applies).
//! 5. Use it where needed with `let v = cfg().field;`. **Copy the value out and drop the guard**
//!    instead of holding the lock across slow work.
//! 6. Document it in the field table of `README.md`.
//!
//! ## Add a ready-made slice
//!
//! `config/defaults.rs` has three lists shown in the "Add a slice" panel:
//! [`presets`](crate::config::presets) (side-button modes), [`quick_actions`](crate::config::quick_actions)
//! and [`blank_items`](crate::config::blank_items). Append an `Item::mode(..)` or `Item::run(..)`.
//! Use [`Shortcut::ch`](crate::keys::Shortcut::ch) for letters and punctuation so the shortcut
//! follows the user's keyboard layout, and the constants in [`keys::key`](crate::keys::key) for
//! layout-independent keys. The first eight presets are indexed by position in
//! `Config::default()`, so append new presets at the end.
//!
//! ## Add a slice kind
//!
//! Larger than it looks, because a slice kind touches every layer:
//!
//! 1. `config/model.rs`: new [`ItemKind`](crate::config::ItemKind) variant.
//! 2. `config/tree.rs` and `config/sanitize.rs`: make `has_commands`, `first_mode` and
//!    `clean_items` aware of it (the compiler points at the exhaustive matches).
//! 3. `tap/resolve.rs`: decide in `select` what releasing over it does.
//! 4. `ui/pie/view.rs` and `ui/pie/mod.rs`: how it is drawn; `ui/settings/pie_designer.rs`
//!    for the designer.
//! 5. `ui/settings/inspector.rs`: the kind chips and the editor body.
//!
//! ## Add a Settings tab
//!
//! 1. `ui/settings/state.rs`: add a variant to `Tab`.
//! 2. `ui/settings/tabs/<name>.rs`: `impl App { pub(in crate::ui::settings) fn <name>_tab(&mut self, ui: &mut egui::Ui) }`
//!    and register the file in `tabs/mod.rs`.
//! 3. `ui/settings/window.rs`: add it to the `sections` array of the sidebar and to the `match` that draws it.
//!
//! Layout rule used throughout the Settings UI: compute widths from the width the caller gives
//! you instead of `available_width()` inside nested layouts, otherwise content can spill out of
//! the card.
//!
//! ## Add a page to the welcome window
//!
//! 1. `ui/settings/welcome.rs`: raise `PAGES` and add a `match` arm in `App::welcome_ui` that calls a
//!    new `fn <name>_page(ui: &mut egui::Ui, ..)`. Pages draw inside the body rectangle; the
//!    footer (dots, Back, Next, Get started) and the top bar (Skip) come from `welcome_ui`.
//! 2. A text that differs between macOS and Windows is a pure function of
//!    [`Os`](crate::platform::Os) next to the others, with a test for both values.
//! 3. State that must survive between pages goes into `Welcome`; anything that must happen when the
//!    window closes belongs in `App::finish_welcome` (`ui/app/windows.rs`), which runs once the
//!    close animation is over for every way of leaving (Skip, Esc, the window's close button).
//! 4. The window shows once per user. To show it again while testing, delete `welcome_shown` from
//!    the app support directory (next to `config.json`), or use "Welcome guide..." in the tray menu.
//!
//! ## Change the installers
//!
//! * macOS: `scripts/bundle.sh` makes the `.app`, `scripts/make-dmg.sh` packs it. The bundle
//!   identifier must stay equal to `about::BUNDLE_ID`.
//! * Windows: `installer/cursorpie.iss` (Inno Setup 6.3 or later) is built by
//!   `scripts/package-windows.ps1`. It installs into the folder the program uses when it installs
//!   itself and writes the same `Run` value, so keep both in step with
//!   `platform/windows/install.rs` and `login_item.rs`. Never change its `AppId`: Windows uses it to
//!   update an existing install. The program recognizes a Setup install by `unins000.exe` in its
//!   folder (`platform::windows::util::installed_by_setup`) and then does not install itself.
//!
//! ## Add icons to the picker
//!
//! Append `ic("glyph", "Name", "search keywords")` to a category in
//! `ui/settings/icon_catalog.rs`. Glyphs are drawn with egui's bundled fonts; if one renders as
//! an empty box, remove it. Users can also drop images into
//! `~/Library/Application Support/CursorPie/icons/`.
//!
//! ## Keep the Settings look consistent
//!
//! The Settings window is a dense, quiet "tool" UI: a graphite window with rounded corners, hairline
//! borders and almost square controls (see `docs/UI_DESIGN.md`). When you add or change a widget:
//!
//! 1. Take colors, radius, spacing and height from `ui/settings/theme.rs` (`BG`, `CARD`, `IDLE`,
//!    `HOT`, `BORDER`, `RADIUS`, `GAP`, `CONTROL_H`). Do not write `Color32::from_rgb(..)`, a corner
//!    radius or a pixel height in an editor. Text on the accent color uses `on_accent(accent)`,
//!    because the user picks the accent and it can be light.
//! 2. Every button, chip, input and list row is `CONTROL_H` (32) high, and there is one gap, `GAP`
//!    (8), between panels and between controls. Do not add your own spacing numbers.
//! 3. A tab is a stack of `panel(ui, "Title", ..)` cards (two columns with `ui.columns(2, ..)` when
//!    it is long). Use the widgets in `ui/settings/widgets.rs` (`chip`, `tile`, `choice`, `toggle`,
//!    `text_field`, `badge`, `info_row`) instead of egui's defaults (`radio_value`, `checkbox`,
//!    `TextEdit::singleline`): they share one marker style and one height. Rows of plain text and
//!    links go in `info_row` (22 px), not in a bare `ui.horizontal` (32 px).
//! 4. Navigation lives in the sidebar and the Undo / Redo / Cancel / Save buttons in the top bar
//!    (`window.rs`), Quit and messages in the footer. A new tab is one more entry in the `sections`
//!    array of the sidebar (a title and a one-line hint) and one more arm in the body `match`.
//!    Start a page with `page_header`, and keep it to one column of `panel`s: the body is capped at
//!    680 pt wide.
//! 5. Text is `TEXT` (primary) or `MUTED` (secondary, for labels and hints). An option that is off
//!    keeps `TEXT`: dim text reads as disabled. Do not rely on `.strong()` for a color, egui takes
//!    it from `widgets.active.fg_stroke`; set the color explicitly.
//! 6. Use words, not emoji, on buttons and chips. Single glyphs are only for tiny icon buttons
//!    (`+`, `✖`, `◀`, `▶`); give those a tooltip.
//! 7. Focus is the accent color: a 2 px border for the selected tile, a 1 px outline for the
//!    hovered one. Do not add shadows or gradients inside panels.
//! 8. Chrome labels (panel titles, badges) are small monospace capitals; text you read or edit, sidebar entries included,
//!    is the normal proportional font in sentence case. `card_title` and `badge` do this for you.
//! 9. Anything with an edge that you draw by hand goes through `ui::draw` (`ring_slice`,
//!    `arc_points`, `snap_rect`); a raw `egui::Mesh` is not anti-aliased.
//!
//! The pie itself stays radial: its slices are picked by angle, and that hit-testing is shared
//! with the event tap (see `geometry.rs`).
//!
//! ## Add a message to the UI thread
//!
//! 1. `msg.rs`: add a variant to [`Msg`](crate::msg::Msg).
//! 2. `ui/app/messages.rs`: handle it in `handle_msg`.
//! 3. Send it with [`Notifier::send`](crate::msg::Notifier::send) (from the tap) or
//!    `tx.send(..)` followed by `ctx.request_repaint()` (from a plain thread).
//!
//! For work that blocks (file choosers, `mdls`) spawn a thread; `ui/settings/picker.rs` has the
//! helper for file choosers.
//!
//! ## Add a menu bar item
//!
//! `ui/tray.rs` builds the menu (`MenuItem::with_id("my_id", ..)`); `ui/app/windows.rs`
//! `handle_tray` receives the id as `Msg::Tray(id)`. "Welcome guide..." is an example: its id
//! `welcome` calls `open_welcome`.
//!
//! ## Cache something in the UI
//!
//! Read [Idle sleep and caches](super::architecture#idle-sleep-and-caches) first.
//!
//! 1. Store it in a [`Lru`](crate::cache::Lru) (or add to [`IconCache`](crate::ui::icons::IconCache)
//!    if it is an icon). Call `new_frame(cap)` once per frame so it stays bounded.
//! 2. Clear it in `App::enter_sleep` (`ui/app/lifecycle.rs`), so it does not outlive an idle period.
//! 3. If the first use would be slow, fill it ahead of time in `App::warm`, which runs when the
//!    trigger is pressed. Never do slow work on the frame that opens the pie.
//! 4. If the source can change on disk, store a stamp ([`FileStamp`](crate::ui::icons::FileStamp))
//!    and drop stale entries in a `revalidate` step instead of clearing everything.
//! 5. Put the pure part (eviction, decisions) in a type with no egui or macOS types and unit test it.
//!
//! ## Keep the profile rules
//!
//! Exactly one profile is general (no apps); every other profile has at least one app. Create
//! profiles with [`Profile::for_app`](crate::config::Profile::for_app) (or `share::add_profile` for
//! imports), never with an empty `apps` list, and offer no way to delete the general profile or the
//! last app of another one. [`Config::sanitize`](crate::config::Config::sanitize) enforces the rule
//! as a last line of defense.
//!
//! ## Make a change undoable
//!
//! Anything stored in the config copy `App::edit` is undoable with no extra code: the history
//! snapshots the whole value every frame. Just edit `self.edit` (Settings widgets already do).
//!
//! * State kept outside the config, such as the selection in `Ed`, is not in the history. After an
//!   undo it can point at something that no longer exists, so read it defensively or extend
//!   `Ed::fit_to`.
//! * If an action replaces `edit` wholesale (import, restore), do not reset the history: the
//!   replacement is a step the user can undo. Call `Ed::reset_nav` (or `fit_to`) afterwards.
//! * A new field of `Config` (or of the types inside it) must keep `PartialEq`: the history compares
//!   values to notice changes.
//!
//! ## Change gesture behavior
//!
//! Gestures live in `tap/`. Re-read the [state machine](super::architecture#the-gesture-state-machine)
//! and the [callback rules](super::architecture#rules-for-the-event-tap-callback) first.
//!
//! * A new state goes into `tap/gesture.rs`; each transition is one function in `tap/trigger.rs`,
//!   dispatched from `trigger::handle`.
//! * Anything that waits (a timer) is a thread that re-checks the gesture `id` after waking up.
//! * Return `CallbackResult::Drop` only for events the program owns; when in doubt use `Keep`.
//! * Pure decisions (which profile, which pie follows the side buttons) belong in code that does
//!   not touch macOS APIs, so they can be unit tested; see [`side::resolve`](crate::side::resolve).
//!
//! ## Rebrand a fork
//!
//! Edit `about.rs` (name, author, links, bundle id), `Cargo.toml`, `LICENSE`, and keep
//! `BUNDLE_ID` identical in `about.rs` and `scripts/bundle.sh`.
//!
//! ### Replace the logo
//!
//! The logo is one function, `draw_logo` in `ui/settings/widgets.rs`. The top bar of the Settings
//! window (`ui/settings/window.rs`, a 24 pt box) and the About tab (`ui/settings/tabs/about.rs`, an
//! 88 pt box) both call it, so keep its signature and change only its body.
//!
//! 1. Keep the SVG as the source file (`assets/logo.svg`) and render a square PNG from it, because
//!    the app has no SVG renderer and adding one would break the "no new dependencies" rule:
//!
//!    ```sh
//!    rsvg-convert -w 256 -h 256 assets/logo.svg -o assets/logo.png
//!    ```
//!
//! 2. Embed the PNG with `include_bytes!`, decode it with the `image` crate (its `png` feature is
//!    already on) and upload it once as an egui texture. A texture is a cache: keep it in one place
//!    and drop it in `App::enter_sleep` (see [Cache something in the UI](#cache-something-in-the-ui)).
//! 3. Draw it with `Painter::image`. A white logo on a transparent background can be tinted with
//!    the accent color, which keeps the old behavior of following the accent.
//! 4. Add a unit test that decodes the embedded PNG, so a broken asset fails `cargo test`.
//!
//! The menu bar / tray icon (`ui/tray.rs`) and the icon of the `.app` bundle are separate and are
//! not changed by this.
